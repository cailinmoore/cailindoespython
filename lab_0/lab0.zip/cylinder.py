#!/usr/bin/env python

from math import pi

#calculate the volume of a cylinder 
h = 5 #height
r = 3 #radius

vol = h*pi*r**2

print(vol)